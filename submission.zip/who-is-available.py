import pymysql.cursors
import sys
from datetime import datetime
from datetime import time

#split date and time
time = sys.argv[1]
date = sys.argv[2]
dateObj = datetime.strptime(date + " " + time, '%Y-%m-%d %H:%M:%S')

if dateObj.weekday() == 5:
    print("Sorry, the clinic is only open from 9am-5pm Mon-Fri")
    print("1")
    sys.exit()

elif dateObj.weekday() == 6:
    print("Sorry, the clinic is only open from 9am-5pm Mon-Fri")
    print("2")
    sys.exit()

connection = pymysql.connect(host='52.70.223.35',
                             user='clinicuser',
                             password='sparky',
                             database='ClinicDB',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

with connection.cursor() as cursor:
    #do stuff
    sql = "SELECT `FirstName`, `LastName` FROM `nurses` WHERE `id`= (SELECT `NurseID` FROM `nurse_schedule` WHERE `SlotDate`=\'" + date + "\' AND `SlotStart`=\'" + time + "\')"
    cursor.execute(sql)
    result = cursor.fetchone()
    print(result['FirstName'] + " " + result['LastName'] + " is available on " + date + " at " + time)
