import pymysql.cursors
import sys

person = sys.argv[1]

connection = pymysql.connect(host='52.70.223.35',
                             user='clinicuser',
                             password='sparky',
                             database='ClinicDB',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

with connection.cursor() as cursor:
    #check is person exists
    sql = "SELECT * FROM `nurses` WHERE `LastName`=\'" + person + "\'"
    cursor.execute(sql)
    result = cursor.fetchone()
    if result == None:
        print("Sorry, but we don't have a Nurse " + person + " in this office.  Make sure to look up your nurse by last name!")
    else:
        sql = "SELECT `SlotDate`, `SlotStart`, `SlotEnd` FROM `nurse_schedule` WHERE `NurseID` = (SELECT `id` FROM `nurses` WHERE `LastName` = \'" + person + "\')"
        cursor.execute(sql)
        result = cursor.fetchone()
        print(person + " is next available on " + str(result['SlotDate']) + " from " + str(result['SlotStart']) + " until " + str(result['SlotEnd']))
