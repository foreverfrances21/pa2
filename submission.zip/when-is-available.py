import pymysql.cursors
import sys
from datetime import datetime
from datetime import time

#split date and time
info = sys.argv[1].split('2',1)
person = info[0]
date = '2' + info[1]
dateObj = datetime.strptime(date, '%Y-%m-%d')

if dateObj.weekday() == 5:
    print("Sorry, the clinic is only open from 9am-5pm Mon-Fri")
    sys.exit()

elif dateObj.weekday() == 6:
    print("Sorry, the clinic is only open from 9am-5pm Mon-Fri")
    sys.exit()
    
connection = pymysql.connect(host='52.70.223.35',
                             user='clinicuser',
                             password='sparky',
                             database='ClinicDB',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

with connection.cursor() as cursor:
    #check is person exists
    sql = "SELECT * FROM `nurses` WHERE `LastName`=\'" + person + "\'"
    cursor.execute(sql)
    result = cursor.fetchone()
    if result == None:
        print("Sorry, but we don't have a Nurse " + person + " in this office.  Make sure to look up your nurse by last name!")
    else:
        #do stuff
        sql = "SELECT `SlotStart`, `SlotEnd` FROM `nurse_schedule` WHERE `SlotDate`=\'" + date + "\' AND `NurseID` = (SELECT `id` FROM `nurses` WHERE `LastName` = \'" + person + "\')"
        cursor.execute(sql)
        result = cursor.fetchone()
        print(person + " is available at " + str(result['SlotStart']) + " until "+ str(result['SlotEnd']) + " on " + date)
